// Task1_Server.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include<stdio.h>
#include<conio.h>
#include<WinSock2.h>
#include<ws2tcpip.h>
#include<stdlib.h>
#pragma comment (lib,"ws2_32.lib")
//#define SERVER_PORT 5500
#define SERVER_ADDR "127.0.0.1"
#define BUFF_SIZE 2048
#pragma warning(disable: 4996)

//check input
boolean checkINPUT(char* buff) {
	int i = 0;
	int lenght = strlen(buff);
	while (i <lenght)
	{
		if ((buff[i] <= 47 || (buff[i] >= 58 && buff[i] <= 64)) || ((buff[i]>90 && buff[i]<97) || buff[i]>122)) return false;
		i++;
	}
	return true;
}
void stringprocessing(char* str1, char* str2, char* str3)
{
	int i = 0;
	int j = 0;
	int k = 0;
	int lenght = strlen(str1);
	while (i < lenght)
	{
		if (str1[i] >= 48 && str1[i] <= 57)
		{
			str2[j] = str1[i];
			i++;
			j++;
		}
		else
		{
			str3[k] = str1[i];
			i++;
			k++;
		}
	}
	str2[j] = 0;
	str3[k] = 0;
}
int main(int argc, char* argv[])
{
	int SERVER_PORT = atoi(argv[1]);
	//Step 1: INITTIATE WISOCK
	WSADATA wsaData;
	WORD wVersion = MAKEWORD(2, 2);
	if (WSAStartup(wVersion, &wsaData))
		printf("Version is not supported\n");

	//step2: construct socket
	SOCKET listenSock;
	listenSock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

	//step3: specify server address
	sockaddr_in serverAddr;
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(SERVER_PORT);
	serverAddr.sin_addr.s_addr = inet_addr(SERVER_ADDR);

	if (bind(listenSock, (sockaddr*)&serverAddr, sizeof(serverAddr)))
	{
		printf("Error! cannot bind this address. ");
		_getch();
		return 0;
	}

	//Step 4: Listen request from client 
	if (listen(listenSock, 10))
	{
		printf("Error! cannot listen. ");
		_getch();
		return 0;
	}

	printf("server started! ");

	//Step 5: communicate with client
	sockaddr_in clientAddr;
	char buff[BUFF_SIZE];
	char buff1[BUFF_SIZE];
	char buff2[BUFF_SIZE];
	int ret, clientAddrLen = sizeof(clientAddr);

	while (1)
	{
		SOCKET connSock;

		//accept request 
		connSock = accept(listenSock, (sockaddr *)& clientAddr, &clientAddrLen);

		// receive message from client
		while (1)
		{
			ret = recv(connSock, buff, BUFF_SIZE, 0);
			//call check input 
			if (ret == SOCKET_ERROR)
			{
				printf("Error: %", WSAGetLastError());
				break;
			}
			else if (strlen(buff) > 0)
			{
				buff[ret] = 0;
				printf("receive from client[%s:%d] %s\n", inet_ntoa(clientAddr.sin_addr), ntohs(clientAddr.sin_port), buff);
				//call check input 
				if (checkINPUT(buff))
				{
					stringprocessing(buff, buff1, buff2);
					strcat(buff1, buff2);
					ret = send(connSock, buff1, strlen(buff1), 0);
					if (ret == SOCKET_ERROR)
						printf("Error: %", WSAGetLastError());
				}
				else
				{
					strcpy(buff, "Input error");
					ret = send(connSock, buff, strlen(buff), 0);
				}
			}
		}
		closesocket(connSock);
	}//end accepting

	 //Step 5: Close socket
	closesocket(listenSock);

	//step6: Terminate Winsock
	WSACleanup();

	return 0;
}
