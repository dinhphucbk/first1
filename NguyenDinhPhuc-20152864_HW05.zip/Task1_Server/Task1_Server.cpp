// Task1_Server.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include<stdio.h>
#include<conio.h>
#include<WinSock2.h>
#include<ws2tcpip.h>
#include <stdlib.h>
#include "process.h"
#pragma comment (lib,"ws2_32.lib")
#define SERVER_ADDR "127.0.0.1"
#define BUFF_SIZE 2048
#define MAX_CLIENT 1024
#pragma warning(disable: 4996)


/* function used to check your user information
** input into a 5 string characters
** start the message information to user
*/

int checkuser(char* buff, char* buff1, char* buff2, char* buff3, char* buff4)
{
	int i = 0;
	int j = 0;
	int k = 0;
	int t = 0;
	int stt;
	while (i < strlen(buff1))
	{
		if (buff1[i] != ' ') {
			buff2[j] = buff1[i];
			i++;
			j++;
		}
		else {
			buff2[j] = 0;
			if (strcmp(buff, buff2) != 0)
			{
				i++;
				while (i < strlen(buff1))
				{
					if (buff1[i] != ' ') {
						buff3[k] = buff1[i];
						i++;
						k++;
					}
					else {
						buff3[k] = 0;
						if (strcmp(buff, buff3) != 0)
						{
							i++;
							while (i < strlen(buff1))
							{
								if (buff1[i] != ' ') {
									buff4[t] = buff1[i];
									i++;
									t++;
								}
								else
								{
									buff4[t] = 0;
									if (strcmp(buff, buff4) != 0) {
										strcpy(buff, "no user");
										stt = 0;
										break;
									}
									else
									{
										strcpy(buff, "enter pass");
										stt = 3;
										break;
									}
								}
							}
							break;
						}
						else
						{
							strcpy(buff, "enter pass");
							stt = 2;
							break;
						}
					}
				}
				break;
			}
			else
			{
				strcpy(buff, "enter pass");
				stt = 1;
				break;
			}
		}
	}
	return stt;
}

/*function used to check pass of user
** input into a 5 string characters
** start the message information to user
*/

void checkpass(char* buff, char* buff1, char* buff2, char* buff3, char* buff4, int stt)
{
	int i = 0;
	int j = 0;
	int k = 0;
	int t = 0;
	while (i < strlen(buff1))
	{
		if (buff1[i] != ' ') {
			buff2[j] = buff1[i];
			i++;
			j++;
		}
		else {
			buff2[j] = 0;
			i++;
			while (i < strlen(buff1))
			{
				if (buff1[i] != ' ') {
					buff3[k] = buff1[i];
					i++;
					k++;
				}
				else {
					buff3[k] = 0;
					i++;
					while (i < strlen(buff1))
					{
						if (buff1[i] != ' ') {
							buff4[t] = buff1[i];
							i++;
							t++;
						}
						else
						{
							buff4[t] = 0;
							break;
						}
					}
					break;
				}
			}
			break;
		}
	}
	if (stt == 1) {
		if (strcmp(buff2, buff) != 0)
		{
			strcpy(buff, "fail pass");
		}
		else
		{
			strcpy(buff, "login success");
		}
	}
	else
	{
		if (stt == 2) {
			if (strcmp(buff3, buff) != 0)
			{
				strcpy(buff, "fail pass");
			}
			else
			{
				strcpy(buff, "login success");
			}
		}
		else {
			if (stt == 3) {
				if (strcmp(buff4, buff) != 0)
				{
					strcpy(buff, "fail pass");
				}
				else
				{
					strcpy(buff, "login success");
				}
			}
		}
	}
}

/*function used to check state of user
** input into a 5 string characters
** start the message information to user
*/
void checkstate(char* buff, char* buff1, char* buff2, char* buff3, char* buff4, int stt)
{
	int i = 0;
	int k = 0;
	int v = 0;
	int t = 0;
	while (i < strlen(buff1))
	{
		//detect the first space
		if (buff1[i] != ' ') {
			buff2[k] = buff1[i];
			i++;
			k++;
		}
		else {
			buff2[k] = 0;
			i++;
			while (i < strlen(buff1))
			{
				if (buff1[i] != ' ')
				{
					buff3[v] = buff[i];
					i++;
					v++;
				}
				else {
					buff3[v] = 0;
					i++;
					while (i<strlen(buff1))
					{
						if ((buff1[i] != 48) && (buff1[i] != 49))
						{
							buff4[t] = 0;
							break;
						}
						else
						{

							buff4[t] = buff1[i];
							i++;
							buff4[t + 1] = 0;
							break;
						}
					}
					break;
				}
			}
			break;
		}
	}
	if (stt == 1) {
		if (strcmp(buff2, "0") != 0)
		{
			strcpy(buff, "login success");
		}
		else
		{
			strcpy(buff, "unclock");
		}
	}
	else
	{
		if (stt == 2) {
			if (strcmp(buff3, "0") != 0)
			{
				strcpy(buff, "login success");
			}
			else
			{
				strcpy(buff, "unclock");
			}
		}
		else {
			if (stt == 3) {
				if (strcmp(buff4, "0") != 0)
				{
					strcpy(buff, "login success");
				}
				else
				{
					strcpy(buff, "unclock");
				}
			}
		}
	}
}
/*function Split the files into strings
** input into a 5 string characters
** out string of user, pass,state
*/
void readline(FILE* f, char* buff1, char* buff2, char* buff3, char* buff4)
{
	int i = 0;
	int j = 0;
	int t = 0;
	int k = 0;
	//clrscr();
	while (!feof(f))
	{
		fgets(buff1, 256, f);
		int i = 0;

		while (i < strlen(buff1))
		{
			if (buff1[i] != ' ') {
				buff2[j] = buff1[i];
				i++;
				j++;
			}
			else {
				buff2[j] = ' ';
				j++;
				i++;
				while (i < strlen(buff1))
				{
					if (buff1[i] != ' ')
					{
						buff3[k] = buff1[i];
						i++;
						k++;
					}
					else
					{
						buff3[k] = ' ';
						i++;
						k++;
						while (i < strlen(buff1))
						{
							if (buff1[i] != '\n')
							{
								buff4[t] = buff1[i];
								i++;
								t++;
							}
							else
							{
								buff4[t] = ' ';
								t++;
								break;
							}
						}
						break;
					}
				}
				break;
			}
		}
	}
	buff2[j++] = 0;// chua ten dang nhap
	buff3[k++] = 0;// chua pass 
	buff4[t++] = 0;// trang thai
}



unsigned _stdcall echoThread(void *param)
{

	char buff[BUFF_SIZE];
	char buff1[BUFF_SIZE];
	char buff2[BUFF_SIZE];
	char buff3[BUFF_SIZE];
	char buff4[BUFF_SIZE];
	char buff5[BUFF_SIZE];
	char buff6[BUFF_SIZE];
	char buff7[BUFF_SIZE];
	char buff8[BUFF_SIZE];
	char buff9[BUFF_SIZE];
	int ret;
	SOCKET connectedSocket = (SOCKET)param;
	// receive message from client
	while (1)
	{
		ret = recv(connectedSocket, buff, BUFF_SIZE, 0);
		if (ret == SOCKET_ERROR)
		{
			printf("Error: %", WSAGetLastError());
		}
		else if (strlen(buff) > 0)
		{
			buff[ret] = 0;
			// open file
			FILE *f1 = fopen("E:\\account.txt", "r+");
			if (f1 == NULL)
			{
				printf("no file account \n");
				return 0;
			}
			else
			{

				readline(f1, buff1, buff2, buff3, buff4);
				//call checkuser
				int stt1 = checkuser(buff, buff2, buff5, buff6, buff7);
				if (!stt1)
				{
					strcpy(buff, "no user");
					ret = send(connectedSocket, buff, strlen(buff), 0);
				}
				else
				{
					checkstate(buff8, buff4, buff5, buff6, buff7, stt1);
					if (strcmp(buff8, "login success") != 0)
					{
						ret = send(connectedSocket, buff8, strlen(buff8), 0);
						if (ret == SOCKET_ERROR)
							printf("Error: %", WSAGetLastError());
					}
					else
					{
						ret = send(connectedSocket, buff, strlen(buff), 0);
						if (ret == SOCKET_ERROR)
							printf("Error: %", WSAGetLastError());
						else
						{
							int count = 0;
							do {
								// receive message from client
								ret = recv(connectedSocket, buff5, BUFF_SIZE, 0);
								buff5[ret] = 0;
								if (ret == SOCKET_ERROR)
									printf("Error: %", WSAGetLastError());
								else if (strcmp(buff5, "") != 0)
								{
									//call checkpass
									int stt = stt1;
									checkpass(buff5, buff3, buff6, buff7, buff9, stt);
									ret = send(connectedSocket, buff5, strlen(buff5), 0);
									count = count + 1;
									if (ret == SOCKET_ERROR)
										printf("Error: %", WSAGetLastError());
								}
							} while ((strcmp(buff5, "login success") != 0) && (count != 3));
						}
					}
				}
			}
		}
	}
	closesocket(connectedSocket);
	return 0;
}


int main(int argc, char* argv[])
{
	int SERVER_PORT = atoi(argv[1]);
	//Step 1: INITTIATE WISOCK
	WSADATA wsaData;
	WORD wVersion = MAKEWORD(2, 2);
	if (WSAStartup(wVersion, &wsaData))
		printf("Version is not supported\n");

	//step2: construct socket
	SOCKET listenSock;
	listenSock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

	//step3: specify server address
	sockaddr_in serverAddr;
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(SERVER_PORT);
	serverAddr.sin_addr.s_addr = inet_addr(SERVER_ADDR);

	if (bind(listenSock, (sockaddr*)&serverAddr, sizeof(serverAddr)))
	{
		printf("Error! cannot bind this address. ");
		_getch();
		return 0;
	}

	//Step 4: Listen request from client 
	if (listen(listenSock, MAX_CLIENT))
	{
		printf("Error! cannot listen. ");
		_getch();
		return 0;
	}

	printf("server started! ");

	//Step 5: communicate with client
	sockaddr_in clientAddr;
	int clientAddrLen = sizeof(clientAddr);
	SOCKET connSocket;

	while (1)
	{
		//accept request 
		connSocket = accept(listenSock, (sockaddr *)& clientAddr, &clientAddrLen);
		printf("connSocket: %d", connSocket);
		_beginthreadex(0, 0, echoThread, (void*)connSocket, 0, 0);
	}//end accepting

	 //Step 5: Close socket
	closesocket(listenSock);

	//step6: Terminate Winsock
	WSACleanup();

	return 0;
}