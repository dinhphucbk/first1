// Task1_Server.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include<stdio.h>
#include<conio.h>
#include<WinSock2.h>
#include<ws2tcpip.h>
#include <stdlib.h>
#pragma comment (lib,"ws2_32.lib")
#define SERVER_ADDR "127.0.0.1"
#define BUFF_SIZE 2048
#pragma warning(disable: 4996)

/* function used to check your user information
** input into a 3 string characters
** start the message information to user
*/

void checkuser(char* buff, char* buff1, char* buff2)
{
	int i = 0;
	while (i < strlen(buff1))
	{
		if (buff1[i] != ' ') {
			buff2[i] = buff1[i];
			i++;
		}
		else {
			buff2[i] = 0;
			break;
		}


	}
	int k = strcmp(buff, buff2);
	if (k != 0)
	{
		strcpy(buff, "no user");
	}
	else
	{
		strcpy(buff, "enter pass");
	}
}

/*function used to check your user information
** input into a 3 string characters
** start the message information to user
*/

void checkpass(char* buff, char* buff1, char* buff2)
{
	int i = 0;
	int k = 0;
	while (i < strlen(buff1))
	{
		//detect the first space
		if (buff1[i] != ' ') {
			i++;
		}
		else {
			int j = i + 1;
			while (j<strlen(buff1))
			{
				if (buff1[j] != ' ')
				{
					buff2[k] = buff1[j];
					k++;
					j++;
				}
				else
				{
					buff2[k] = 0;
					break;
				}
			}
			break;
		}
	}
	int j = strcmp(buff, buff2);
	if (j != 0)
	{
		strcpy(buff, "fail pass");
	}
	else
	{
		strcpy(buff, "login success");
	}
}
int main(int argc, char* argv[])
{
	int SERVER_PORT = atoi(argv[1]);
	//Step 1: INITTIATE WISOCK
	WSADATA wsaData;
	WORD wVersion = MAKEWORD(2, 2);
	if (WSAStartup(wVersion, &wsaData))
		printf("Version is not supported\n");

	//step2: construct socket
	SOCKET listenSock;
	listenSock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

	//step3: specify server address
	sockaddr_in serverAddr;
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(SERVER_PORT);
	serverAddr.sin_addr.s_addr = inet_addr(SERVER_ADDR);

	if (bind(listenSock, (sockaddr*)&serverAddr, sizeof(serverAddr)))
	{
		printf("Error! cannot bind this address. ");
		_getch();
		return 0;
	}

	//Step 4: Listen request from client 
	if (listen(listenSock, 10))
	{
		printf("Error! cannot listen. ");
		_getch();
		return 0;
	}

	printf("server started! ");

	//Step 5: communicate with client
	sockaddr_in clientAddr;
	char buff[BUFF_SIZE];
	char buff1[BUFF_SIZE];
	char buff2[BUFF_SIZE];
	char buff3[BUFF_SIZE];
	int ret, clientAddrLen = sizeof(clientAddr);

	while (1)
	{
		SOCKET connSock;

		//accept request 
		connSock = accept(listenSock, (sockaddr *)& clientAddr, &clientAddrLen);
		while (1)
		{
			// receive message from client
			ret = recv(connSock, buff, BUFF_SIZE, 0);
			if (ret == SOCKET_ERROR)
			{
				printf("Error: %", WSAGetLastError());
				break;
			}
			else if (strlen(buff) > 0)
			{
				buff[ret] = 0;
				// open file
				FILE *f1 = fopen("E:\\account.txt", "r+");
				if (f1 == NULL)
				{
					printf("no file account \n");
					return 0;
				}
				else
				{
					fgets(buff1, 90, f1);
					//call checkuser
					checkuser(buff, buff1, buff2);
					ret = send(connSock, buff, strlen(buff), 0);
					if (ret == SOCKET_ERROR)
						printf("Error: %", WSAGetLastError());
					else
					{
						// receive message from client
						ret = recv(connSock, buff3, BUFF_SIZE, 0);
						buff3[ret] = 0;
						//call checkpass
						checkpass(buff3, buff1, buff2);
						ret = send(connSock, buff3, strlen(buff3), 0);
						if (ret == SOCKET_ERROR)
							printf("Error: %", WSAGetLastError());
					}
				}
			}
		}
		closesocket(connSock);
	}//end accepting

	 //Step 5: Close socket
	closesocket(listenSock);

	//step6: Terminate Winsock
	WSACleanup();

	return 0;
}

