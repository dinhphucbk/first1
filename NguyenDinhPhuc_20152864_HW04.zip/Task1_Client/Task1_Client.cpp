// Task1_Client.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include<stdio.h>
#include<conio.h>
#include<string.h>
#include<stdlib.h>
#include<WinSock2.h>
#include<ws2tcpip.h>
#pragma comment (lib,"ws2_32.lib")
#define BUFF_SIZE 2048
#pragma warning(disable: 4996)

int main(int argc, char* argv[])
{
	int SERVER_PORT = atoi(argv[2]);
	//Step 1: INITTIATE WISOCK
	WSADATA wsaData;
	WORD wVersion = MAKEWORD(2, 2);
	if (WSAStartup(wVersion, &wsaData))
		printf("Version is not supported\n");

	//step2: construct socket
	SOCKET client;
	client = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

	//(optional)set-time-out for receiving
	int tv = 10000;
	//time out interval: 10000;
	setsockopt(client, SOL_SOCKET, SO_RCVTIMEO, (const char*)(&tv), sizeof(int));

	//step3: specify server address
	sockaddr_in serverAddr;
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(SERVER_PORT);
	serverAddr.sin_addr.s_addr = inet_addr(argv[1]);

	//step 4: request to connect server 
	if (connect(client, (sockaddr*)&serverAddr, sizeof(serverAddr)))
	{
		printf("Error! cannot connect server. %d ", WSAGetLastError());
		_getch();
		return 0;
	}
	printf("connected server!\n");

	//Step 5: communicate with server

	char buff[BUFF_SIZE];
	int ret;
	do
	{
		//send message
		printf("log in:\n");
		printf("Enter username: \n");
		gets_s(buff, BUFF_SIZE);
		ret = send(client, buff, strlen(buff), 0);
		if (ret == SOCKET_ERROR)
			printf("Error! cannot receive message. ");

		//receive echo message
		ret = recv(client, buff, BUFF_SIZE, 0);
		buff[ret] = 0;
		if (ret == SOCKET_ERROR)
		{
			if (WSAGetLastError() == WSAETIMEDOUT)
				printf("Time-out!");
			else printf("Error! cannot receive message. ");
		}
		else if (strlen(buff) > 0)
		{
			//Check user information is correct
			if (strcmp(buff, "enter pass") != 0)
			{
				printf("no user\n");
				continue;
			}
			else {
				printf("pass:\n");
				gets_s(buff, BUFF_SIZE);
				ret = send(client, buff, strlen(buff), 0);
				if (ret == SOCKET_ERROR)
					printf("Error! cannot receive message. ");
				else {

					ret = recv(client, buff, BUFF_SIZE, 0);
					buff[ret] = 0;
					if (ret == SOCKET_ERROR)
					{
						if (WSAGetLastError() == WSAETIMEDOUT)
							printf("Time-out!");
						else printf("Error! cannot receive message. ");
					}
					else if (strlen(buff) > 0)
					{
						//Login check succeeded
						if (strcmp(buff, "login success") != 0) printf("faile pass \n");
						else
						{
							printf("success!!! \n");
						}
					}
				}
			}
		}
	} while (strcmp(buff, "") != 0);

	closesocket(client);

	//step 7: Terminate Winsock
	WSACleanup();

	_getch();
	return 0;
}

